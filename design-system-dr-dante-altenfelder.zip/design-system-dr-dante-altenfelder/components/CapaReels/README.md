# CapaReels

Capa de Reels 1080 × 1920: foto em tela cheia com véu, logo no topo e título no terço de baixo.

- **Você fornece**: foto vertical, título de 1 a 3 palavras, subtítulo, opcionalmente a pílula.
- `da-slide da-slide--reels` > `da-reels-foto` + `da-reels-veu` + `da-logo` + `da-reels-texto`.
- Título em `marfim` 130 a 150 px; subtítulo `ouro-claro` 60 px com a palavra chave em itálico.
- Para séries (CONTANDO CASOS) use `da-reels-veu--verde`, título enorme centralizado logo abaixo do logo.
- Mantenha o rosto e o texto fora da faixa de 250 px da base (interface do Instagram).
