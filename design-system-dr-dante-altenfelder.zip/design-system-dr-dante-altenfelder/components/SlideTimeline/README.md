# SlideTimeline

Slide de credenciais ou etapas em linha do tempo vertical.

- **Você fornece**: título (MINHA **FORMAÇÃO**), frase de abertura, 3 a 6 itens.
- `ul.da-timeline` com o começo de cada item em `<em>`; itens terminam em ponto e vírgula, o último em ponto.
- Fundo `verde`, linha e pontos `ouro-claro`, texto `marfim` a 34 a 36 px.
