# CarrosselPanorama

Carrossel de 4 slides montado como uma tela única de 4320 × 1440, com o monograma atravessando a emenda.

- **Você fornece**: os 4 slides (capa, contexto, aprofundamento, CTA) em sequência de fundos alternados.
- `da-panorama` com os 4 `da-slide` lado a lado e uma camada `da-panorama__sobre` para o que cruza as emendas.
- Troca de cor na emenda: o mesmo monograma é colocado duas vezes, recortado por cada slide (verde dentro do ouro, ouro dentro do verde), na mesma posição global.
- Exporte cortando em x = 0, 1080, 2160, 3240. Confira que nada essencial cai a menos de 120 px de uma emenda.
