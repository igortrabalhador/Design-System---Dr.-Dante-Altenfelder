# PostUnico

Post único 1080 × 1440 que entrega o conteúdo inteiro em um slide.

- **Você fornece**: título em pergunta, 3 a 5 tópicos curtos.
- Título `marfim` centralizado, primeira linha menor, palavra chave em `<b>`, as últimas linhas maiores em `<em>`.
- Tópicos em `da-lista-centro da-corpo` na cor `ouro-claro`, com o início de cada um em itálico.
- Fecha com `da-regua` e o logotipo `creme`.
