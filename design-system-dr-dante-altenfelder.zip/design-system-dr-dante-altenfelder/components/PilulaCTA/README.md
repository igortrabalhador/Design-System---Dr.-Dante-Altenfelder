# PilulaCTA

Chamada para ação em pílula com contorno dourado.

- **Você fornece**: o texto, em minúsculas, com a parte final em `<em>`.
- `span.da-cta`: borda 3 px `ouro-claro`, texto `marfim` 36 px, final em itálico `ouro-claro`. Em fundos claros a borda e o texto viram `verde`.
- Um CTA por peça, no último slide ou na capa de Reels.
