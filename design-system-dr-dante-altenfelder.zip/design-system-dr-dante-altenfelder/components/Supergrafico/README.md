# Supergrafico

O monograma DA ampliado como grafismo de fundo, sangrando pelas bordas.

- **Você fornece**: o slide e a posição; use `img.da-mono` com `monograma-ouro` (verde, areia, creme) ou `monograma-verde` (ouro).
- Altura entre 1200 e 1700 px (traço de ~30 a 40 px). Mostre só um pedaço: o arco do D, as duas barras verticais ou as pernas do A.
- Fica atrás do texto e das fotos e nunca cruza um título.
