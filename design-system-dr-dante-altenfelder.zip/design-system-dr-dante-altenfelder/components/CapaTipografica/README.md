# CapaTipografica

Capa de carrossel só com texto, em areia (centralizada) ou verde (alinhada à esquerda).

- **Você fornece**: o gancho (pergunta ou afirmação), um subtítulo de uma frase, o fundo.
- Estrutura: `da-slide da-fundo-areia|verde da-seda` > `da-etiquetas` + `da-conteudo` (`da-titulo` + `da-subtitulo`) + `da-logo`.
- Título entre 80 e 128 px, entrelinha 0.86 a 0.9, uma expressão em `<em>` ou `<strong>`.
- No areia: título `verde`, subtítulo `ouro-escuro` com destaque em itálico. No verde: título `ouro-claro` em itálico, subtítulo `marfim`.
- Não use foto aqui; se a capa precisa do doutor, use `CapaComFoto`.
