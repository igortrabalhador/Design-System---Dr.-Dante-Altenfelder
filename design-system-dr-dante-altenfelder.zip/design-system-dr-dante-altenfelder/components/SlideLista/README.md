# SlideLista

Slide de lista centralizada com marcador •, sobre `creme`.

- **Você fornece**: título em duas linhas, frase de contexto, 3 a 6 itens curtos.
- Título `ouro-escuro` Light Italic ~62 px; corpo `verde-suave` com os trechos importantes em `<em>` (`verde`); itens em `verde`.
- Itens de uma linha; se passarem de duas, troque por `SlideTimeline`.
