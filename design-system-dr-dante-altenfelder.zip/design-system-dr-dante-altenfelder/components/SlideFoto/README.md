# SlideFoto

Slide com foto: retângulo reto abaixo do texto (ouro) ou cartão arredondado abaixo do título (verde).

- **Você fornece**: título, texto curto, uma foto de detalhe ou ilustrativa.
- No ouro, a foto fica alinhada à esquerda e o monograma `verde` cruza por trás, abaixo do texto.
- No verde, foto em cartão `radius-foto` de ~844 × 556 px, título reto `marfim` e pergunta em `ouro-claro`.
