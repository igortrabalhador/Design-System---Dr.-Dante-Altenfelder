# SlideTexto

Slide interno de título e corpo: centralizado no verde ou em coluna no ouro.

- **Você fornece**: título curto com uma palavra forte, 1 ou 2 parágrafos de até 6 linhas.
- No verde: título `ouro-claro`, corpo `marfim`, destaque em `<em class="r">` (dourado).
- No ouro: título e corpo `verde`, destaque `<em class="r">` em `marfim`; entre parágrafos, `da-regua`; o segundo parágrafo pode vir alinhado à direita como contraponto.
- Não ultrapasse 760 px de largura de texto nem 12 linhas no slide.
