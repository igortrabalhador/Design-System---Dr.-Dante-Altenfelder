# CapaComFoto

Capa com o título no terço de cima e a foto do doutor ocupando a parte de baixo até as bordas.

- **Você fornece**: título curto (2 linhas), subtítulo, foto horizontal do doutor.
- Fundo `ouro`; título `verde` Light reto a ~104 px; subtítulo `verde` com destaque `marfim` itálico.
- A foto começa em y = 632 e vai até a base, sem cantos arredondados. O monograma `verde` aparece entre o texto e a foto, por trás dela.
- Logotipo `creme` sobre a foto, no rodapé.
