# SlideCTA

Último slide do carrossel: frase de fechamento e pílula de CTA, sempre em `verde`.

- **Você fornece**: título de 2 linhas, uma frase de compromisso, o texto do CTA.
- Centralizado; `da-cta` 56 px abaixo do corpo.
- Texto padrão do CTA: "agende sua consulta no *link da bio.*" 
