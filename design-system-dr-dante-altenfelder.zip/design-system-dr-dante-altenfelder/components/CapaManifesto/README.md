# CapaManifesto

Capa de frase curta empilhada, cada linha ajustada à mesma largura, em itálico `ouro` sobre `areia`.

- **Você fornece**: uma frase de 4 a 7 palavras quebrada em 4 a 6 linhas.
- Linhas com `<span class="l">`; as palavras chave (CÂNCER, CIRURGIA) em `<strong>`.
- Largura do bloco 684 px; o script da prévia calcula o tamanho de cada linha (`data-largura`). Em ferramentas de design, ajuste cada linha à mão até as bordas alinharem.
- Contraste `ouro` sobre `areia` é baixo (1.9:1): só funciona porque as letras passam de 100 px. Nunca use essa combinação em texto menor.
