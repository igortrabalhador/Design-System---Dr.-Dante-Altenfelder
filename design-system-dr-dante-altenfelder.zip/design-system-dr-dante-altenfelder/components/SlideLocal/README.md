# SlideLocal

Slide de local de atendimento: nome, endereço, foto da fachada com mapa sobreposto.

- **Você fornece**: nome do local, endereço, foto da fachada, recorte do mapa.
- Nome em duas linhas: parte principal em `<strong>`, complemento em `<em>`.
- Endereço `corpo-pequeno` em `ouro-escuro` (no creme) com o bairro em itálico.
- `da-local` com `da-foto` (cantos 40 px) e `da-mapa` (320 px, cantos 32 px) saindo 40 px pela direita e pela base.
- Alterne creme e ouro entre dois locais seguidos.
