Sistema visual do Instagram do Dr. Dante Altenfelder, médico cirurgião oncológico (A.C.Camargo Cancer Center). Feito para produzir **carrosséis** de 4 slides, posts únicos e capas de Reels que pareçam saídos da mesma mão: sóbrios, elegantes, com verde profundo, dourado e areia, títulos em serifa clássica e texto leve em sans.

Antes de criar uma peça, abra as imagens do grupo **Referencias**: são as peças reais que definem este sistema.

## Formatos

| Peça | Canvas | Observação |
| --- | --- | --- |
| Slide de carrossel | 1080 × 1440 px (3:4) | Carrossel = 4 slides, pensado como uma tela única de 4320 × 1440 e cortado a cada 1080 px |
| Post único | 1080 × 1440 px | Mesmo esqueleto da capa, com o conteúdo inteiro no próprio slide |
| Capa de Reels | 1080 × 1920 px (9:16) | Foto em tela cheia, véu escuro, logo no topo, título no terço de baixo |

Desenhe sempre no tamanho real e exporte 1:1. Margem de segurança `margem` (120 px) nas laterais e no topo; o logotipo fica a `margem-base` (104 px) da borda inferior.

## Voz e conteúdo

- **Primeira pessoa, médico falando com o paciente.** "Sou o Dr. Dante Altenfelder.", "Escolhi dedicar minha carreira…", "É por isso que eu acredito em uma abordagem multidisciplinar." O leitor é tratado por **você**.
- **Educativo, calmo e acolhedor.** Explica um exame, um sinal, uma forma de tratamento; nunca assusta, nunca promete resultado. Fecha com esperança ou com cuidado: "Tenha esperança, ela também faz parte do tratamento."
- **Ganchos de capa** em forma de pergunta ou afirmação forte: "Você sabe o que é um Tumor Board?", "A endoscopia salva vidas.", "O que fazer após o diagnóstico de câncer?", "4 sinais que podem indicar câncer de pâncreas".
- **Termos técnicos sempre explicados** em linguagem simples logo em seguida (Tumor Board é "uma reunião multidisciplinar para discutir o caso").
- **Credenciais com nome completo**: A.C.Camargo Cancer Center, Sociedade Brasileira de Cirurgia Oncológica (SBCO), Universidade de Harvard (PPCR), Cirurgia Robótica.
- **CTA padrão**, sempre em minúsculas e terminando em ponto: "agende sua consulta no *link da bio.*"
- **Sem emojis, sem exclamações, sem hashtags dentro da arte.** Acentuação sempre revisada (as peças antigas têm "Oncologico", "instituiçao", "Certificaçao": não repetir).
- Publicidade médica segue as regras do CFM: sem sensacionalismo, sem promessa de cura, sem antes e depois.

## Arco do carrossel (4 slides)

1. **Capa**: gancho + subtítulo curto (`CapaTipografica`, `CapaComFoto` ou `CapaManifesto`). Etiquetas de topo e logo.
2. **Contexto**: o problema ou a explicação (`SlideTexto`, `SlideLista`, `SlideTimeline`).
3. **Aprofundamento**: o exame, o tratamento, o local, com foto (`SlideFoto`, `SlideLocal`).
4. **Fechamento**: a mensagem do doutor e a pílula de CTA (`SlideCTA`).

Os fundos **alternam** de um slide para o outro, nunca dois iguais seguidos (exceto quando dois verdes formam um painel duplo, com uma foto atravessando a emenda). Sequências reais: areia, ouro, verde, verde · verde, creme, ouro, verde · ouro, verde, ouro, verde. **O último slide é sempre verde.**

## Cores

- `verde` é a cor da marca e o fundo mais usado. Sobre ele: títulos em `ouro-claro` (ou `marfim` em capas), corpo em `marfim`, destaques em `ouro-claro`.
- `ouro` é o fundo dos slides intermediários. Sobre ele: título e corpo em `verde`; destaques curtos em `marfim` itálico.
- `areia` (capas claras) e `creme` (slides de endereço e lista). Sobre eles: títulos em `verde`, corpo em `verde-suave` com destaques em `verde`, subtítulos e endereços em `ouro-escuro`.
- `verde-logo` é a tinta original do logotipo; `verde-sombra` e `verde-brilho` só existem na textura.
- **Contraste**: as peças originais usam texto `marfim` sobre `ouro` (2.5:1) e títulos `ouro` sobre `creme` (2.3:1), ambos abaixo do mínimo de leitura. Mantenha `marfim` sobre `ouro` apenas em frases curtas em itálico a 40 px ou mais, e troque `ouro` por `ouro-escuro` em qualquer texto sobre fundo claro abaixo de 60 px.
- Nada de outras cores. Os ícones laranja e amarelos do post de pâncreas fogem da paleta; ao refazer listas com ícones, use traço `verde` sobre `creme`.

## Tipografia

Duas famílias, nunca uma terceira.

**Cormorant Garamond** (`--font-serif`), sempre em **CAIXA ALTA**, para títulos e etiquetas. O efeito da marca está em **misturar pesos dentro do mesmo título**:

- palavras comuns em Light (reto) ou Light Italic;
- a palavra chave em **SemiBold Italic** (ou SemiBold reto): "MINHA **FORMAÇÃO**", "ESCOLHI DEDICAR MINHA **CARREIRA**", "MUITAS DOENÇAS DO **APARELHO DIGESTIVO,**", "O QUE **FAZER APÓS** O DIAGNÓSTICO";
- no máximo duas expressões fortes por título;
- entrelinha bem fechada (0.8 a 0.9): o acento de uma linha quase encosta na base da de cima;
- títulos podem terminar em ponto ("SALVA VIDAS.", "DR. DANTE ALTENFELDER.") ou vírgula, quando o corpo continua a frase ("MUITAS DOENÇAS DO APARELHO DIGESTIVO," seguido de "incluindo alguns tipos de câncer…").

Em HTML (classes de `components/bundle.css`): texto solto = Light, `<em>` = Light Italic, `<strong>` = SemiBold Italic, `<b>` = SemiBold reto.

**Poppins** (`--font-sans`) para tudo o que é frase: subtítulo, corpo, listas, endereços, CTA. Peso Light (300) no texto e **Poppins Italic (400)** nos trechos destacados, que também podem mudar de cor. Frases em caixa normal, nunca em caixa alta. O corpo fica entre 32 e 44 px no canvas de 1080 e a entrelinha em 1.1.

Escala (estilos em `tokens.json`): `titulo-manifesto` 200 · `titulo-reels` 150 · `titulo-capa` 128 · `titulo-slide` 84 · `titulo-secundario` 60 · `etiqueta` 32 · `subtitulo` 44 · `corpo` 38 · `corpo-pequeno` 32 · `cta` 36.

**Capa manifesto**: frase curta empilhada em 4 a 6 linhas, cada linha ajustada para ter exatamente a mesma largura (as palavras curtas ficam enormes), tudo em itálico `ouro` sobre `areia`.

## Composição do slide

- **Etiquetas de topo** em `etiqueta`: ONCOLOGIA à esquerda e DIAGNÓSTICO à direita (ou o tema do post), a 120 px do topo. Aparecem na capa e no post único; nos slides internos são opcionais.
- **Logotipo horizontal** centralizado no rodapé, 266 px de largura, na capa e no post único (`verde` sobre claro, `creme` ou `ouro` sobre verde e sobre foto).
- Alinhamento varia por slide para dar ritmo: centralizado em frases de impacto; à esquerda em listas e textos longos; à direita em um parágrafo de contraponto (veja o slide "Escolhi dedicar minha carreira").
- **Régua divisória**: traço de 130 a 360 px por 4 px, em `ouro-claro` no verde, `marfim` translúcido no ouro, `ouro` no claro. Separa parágrafos ou encerra uma lista.
- **Timeline**: lista de credenciais com linha vertical e pontos de 14 px em `ouro-claro`.
- **Pílula de CTA**: contorno de 3 px em `ouro-claro`, cantos totalmente arredondados, texto `cta` em `marfim` com o final em itálico `ouro-claro`.
- **Fotos**: em cartão com cantos `radius-foto` (40 px) quando são ilustrativas; em retângulo reto quando é o doutor, sangrando até a borda (capa com foto) ou atravessando a emenda entre dois slides. Mapa sobreposto ao canto inferior direito da foto do local, com `radius-mapa`.
- **Fundos**: cor chapada com textura de seda/cetim suave (classe `da-seda`), nunca degradê colorido.

## Supergráfico: o monograma DA

A assinatura gráfica dos carrosséis é o próprio monograma (o arco do D e as pernas do A) **ampliado a cerca de 1200 a 1700 px de altura**, cortado pelas bordas, atrás do conteúdo:

- `monograma-ouro` sobre `verde`, `areia` e `creme`; `monograma-verde` sobre `ouro`;
- ele **atravessa a emenda** entre dois slides e **troca de cor** ao passar de um fundo para o outro (verde no slide dourado, dourado no slide verde seguinte), criando a continuidade que convida a deslizar;
- nunca cruza títulos nem corpo de texto; fica nas áreas vazias e por trás das fotos;
- um monograma por par de slides, no máximo.

## Fotografia

Fotos reais do doutor (camisa clara, gravata escura, ambiente de consultório e janela com vista), da fachada dos locais e, em temas de procedimento, imagens de detalhe (endoscópio, modelo anatômico, mãos, mesa de consulta). Luz natural, tons frios ou neutros. Em capas de Reels, véu escuro (`veu-reels`) na metade de baixo, ou véu verde quase opaco para capas de série ("CONTANDO CASOS").

## Locais de atendimento (conteúdo fixo)

- **A.C.Camargo Cancer Center**: Rua Professor Antônio Prudente, 211, Liberdade, São Paulo/SP.
- **Clínica Oliveira Santos**: Av. Brigadeiro Luís Antônio, 4237, Jardim Paulista, São Paulo/SP.

## Arquivos

- `assets/Logos`: logotipo horizontal e monograma em verde, creme e ouro (SVG vetorial extraído do PDF oficial).
- `assets/Fotos`: recortes das peças existentes para estudo e protótipo; em produção use os arquivos originais em alta.
- `assets/Referencias`: todas as peças enviadas, para comparar o resultado antes de exportar.
- `components/bundle.css`: classes `da-*` para montar slides em HTML no tamanho real (`da-slide`, `da-fundo-*`, `da-seda`, `da-etiquetas`, `da-logo`, `da-conteudo`, `da-titulo`, `da-corpo`, `da-regua`, `da-timeline`, `da-cta`, `da-foto`, `da-local`, `da-mono`, `da-panorama`).
- `fonts/`: Cormorant Garamond Light, Light Italic, Italic, SemiBold, SemiBold Italic e Poppins Light, Light Italic, Regular, Italic.
